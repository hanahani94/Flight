Assignment for DDAC- Ukraine Airlines
Nur Raihana Farhani Binti Mpohd Nozeri